/**
 *  @note This file is part of MABE, https://github.com/mercere99/MABE2
 *  @copyright Copyright (C) Michigan State University, MIT Software license; see doc/LICENSE.md
 *  @date 2021-2022.
 *
 *  @file  EvalTaskAndnot.h
 *  @brief Tests organism output for bitwise ANDNOT operation
 *
 *  A ANDNOT B is equal to A AND (~B), where ~ is bitwise NOT 
 *  Here, however, we check both directions. So we also look for B AND (~A).
 */

#ifndef MABE_EVAL_TASK_ANDNOTB_H
#define MABE_EVAL_TASK_ANDNOTB_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise ANDNOT operation
  class EvalTaskAndnotB : public EvalTaskBase<EvalTaskAndnotB, 2> {

  public:
    EvalTaskAndnotB(mabe::MABE & control,
                  const std::string & name="EvalTaskAndnotB",
                  const std::string & desc="Evaluate organism on ANDNOTB logic task")
      : EvalTaskBase(control, name, "andnotB", desc){;}

    ~EvalTaskAndnotB() { }

    /// Check if passed output is equal to input_a ANDNOT input_b or input_b ANDNOT input_a 
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return output == (input_a & ~input_b);
    }
  };

  MABE_REGISTER_MODULE(EvalTaskAndnotB, "Organism-triggered evaluation of ANDNOTB operation");

}

#endif
