/**
 *  @note This file is part of MABE, https://github.com/mercere99/MABE2
 *  @copyright Copyright (C) Michigan State University, MIT Software license; see doc/LICENSE.md
 *  @date 2021-2022.
 *
 *  @file  EvalTaskNotNA.h
 *  @brief Tests organism output for bitwise NOT operation
 */

#ifndef MABE_EVAL_TASK_NOTNA_H
#define MABE_EVAL_TASK_NOTNA_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise NOT operation
  class EvalTaskNotNA : public EvalTaskBase<EvalTaskNotNA, 1> {
  public:
    EvalTaskNotNA(mabe::MABE & control,
                  const std::string & name="EvalTaskNotNA",
                  const std::string & desc="Evaluate organism on NOTNA logic task")
      : EvalTaskBase(control, name, "notNA", desc){;}

    /// Check if the passed output is bitwise NOT of the passed input  
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b) 
      return output == ~input_a;
    }
  };
    
  MABE_REGISTER_MODULE(EvalTaskNotNA, "Organism-triggered evaluation of NOTNA operation");

}

#endif
