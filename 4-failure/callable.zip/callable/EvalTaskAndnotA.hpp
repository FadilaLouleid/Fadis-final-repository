#ifndef MABE_EVAL_TASK_ANDNOTA_H
#define MABE_EVAL_TASK_ANDNOTA_H

#include "./EvalTaskBase.hpp"

namespace mabe {

  /// \brief Tests organism output for bitwise ANDNOT operation
  class EvalTaskAndnotA : public EvalTaskBase<EvalTaskAndnotA, 2> {

  public:
    EvalTaskAndnotA(mabe::MABE & control,
                  const std::string & name="EvalTaskAndnotA",
                  const std::string & desc="Evaluate organism on ANDNOTA logic task")
      : EvalTaskBase(control, name, "andnotA", desc){;}

    ~EvalTaskAndnotA() { }

    /// Check if passed output is equal to input_a ANDNOT input_b or input_b ANDNOT input_a 
    bool CheckTwoArg(const data_t& output, const data_t& input_a, const data_t& input_b){
      return  output == (input_b & ~input_a);
    }
  };

  MABE_REGISTER_MODULE(EvalTaskAndnotA, "Organism-triggered evaluation of ANDNOTA operation");

}

#endif
