
#ifndef BITSPOP_H_
#define BITSPOP_H_

#include "BitsOrganism.h"

class BitsPop {    //object is BitsOrganism
// the vector contains a pointer called pop . pop holds the organisms in the population 
    std::vector<BitsOrganism *> pop;
    int popsize;  //integer that holds the number of organisms in the population 

public:

    BitsPop(int n, int genomesize) {
        popsize = n;
        for (int i = 0; i < n; i++) {
            BitsOrganism* org = new BitsOrganism(genomesize);
            pop.push_back(org);
        }
    }

    void update(const std::vector<BitsOrganism*> & newpop) {
        pop = newpop;
    }

    std::vector<BitsOrganism*> getPop() {
        return pop;
    }

    BitsOrganism* getMax() {
        auto it = std::max_element(pop.begin(), pop.end());
        return *it;
    }


    std::vector<BitsOrganism*> tournament_select(int tournsize) {
        // step 1 : set up your implementation


        std::vector<BitsOrganism*> newpop; // create new vector to hold the selected organisms 
        newpop.reserve(popsize); // reserve memory for it 



        // step 2: randomly select tournsize organisms for the tournament 



        for (int i = 1 ; i < popsize; i++ ){  //creating a turnement by randomly selecting tournmentsize organisms for the population 

        std::vector<BitsOrganism*> tournament; //creating a tournement vector 
        tournament.reserve(tournsize); //saving memory for it 


        for (int j = 0; j < tournsize; j++) {  //The loop selects tournsize organisms by randomly 
        //going through the population vector pop and wraping around if necessary.
            tournament.push_back(pop[rand() % popsize]);
        }



         // Step 3: find the organism with the highest fitness in the tournament
      


        auto it = std::max_element(tournament.begin(), tournament.end());
        newpop.push_back(*it);
          }
        //returns the newpop vector containing the selected organisms.
         return newpop;
        }
  


  std::vector<BitsOrganism*> roulette_select() {
        // your implementation
    }
    };
 

#endif /*BITSPOP_H_*/